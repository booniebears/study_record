#!/bin/bash

code ../nscscc2021_group_v0.01/func_test_v0.01/soft/func/
