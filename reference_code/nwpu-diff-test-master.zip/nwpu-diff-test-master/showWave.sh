#!/bin/bash

gtkwave ./build/run.vcd
