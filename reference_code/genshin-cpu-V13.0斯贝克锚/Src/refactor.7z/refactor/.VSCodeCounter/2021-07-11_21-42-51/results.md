# Summary

Date : 2021-07-11 21:42:51

Directory c:\Users\ywj\Desktop\GitLab\CPU_OPT\Src\refactor

Total : 42 files,  7870 codes, 958 comments, 852 blanks, all 9680 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| SystemVerilog | 42 | 7,870 | 958 | 852 | 9,680 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 42 | 7,870 | 958 | 852 | 9,680 |
| EXE | 11 | 975 | 165 | 88 | 1,228 |
| ID | 6 | 1,577 | 100 | 175 | 1,852 |
| IF1 | 4 | 536 | 115 | 98 | 749 |
| MEM1 | 5 | 1,472 | 150 | 169 | 1,791 |
| MEM2 | 2 | 116 | 14 | 12 | 142 |
| WB | 3 | 192 | 35 | 17 | 244 |

[details](details.md)