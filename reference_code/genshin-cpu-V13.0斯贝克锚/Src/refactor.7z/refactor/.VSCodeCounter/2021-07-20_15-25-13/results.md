# Summary

Date : 2021-07-20 15:25:13

Directory c:\Users\ywj\Desktop\GitLab\OPT_refactor\Src\refactor

Total : 46 files,  9364 codes, 1290 comments, 1048 blanks, all 11702 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| SystemVerilog | 46 | 9,364 | 1,290 | 1,048 | 11,702 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 46 | 9,364 | 1,290 | 1,048 | 11,702 |
| EXE | 10 | 1,053 | 212 | 104 | 1,369 |
| ID | 7 | 1,936 | 122 | 192 | 2,250 |
| IF | 2 | 47 | 21 | 10 | 78 |
| MEM1 | 7 | 1,653 | 194 | 166 | 2,013 |
| MEM2 | 2 | 132 | 44 | 14 | 190 |
| PRE_IF | 5 | 627 | 98 | 113 | 838 |
| Utils | 2 | 173 | 66 | 40 | 279 |
| WB | 2 | 91 | 53 | 13 | 157 |

[details](details.md)